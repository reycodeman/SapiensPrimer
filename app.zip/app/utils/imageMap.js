const pieceImages = {
  w1: require('../assets/images/w1.png'),
  w2: require('../assets/images/w2.png'),
  w3: require('../assets/images/w3.png'),
  w4: require('../assets/images/w4.png'),
  w5: require('../assets/images/w5.png'),
  w6: require('../assets/images/w6.png'),
  b1: require('../assets/images/b1.png'),
  b2: require('../assets/images/b2.png'),
  b3: require('../assets/images/b3.png'),
  b4: require('../assets/images/b4.png'),
  b5: require('../assets/images/b5.png'),
  b6: require('../assets/images/b6.png'),
  // Adicione outras variantes, como rotacionadas: w3r, b2r, etc
};

export default pieceImages;
