export const initialBoard = [
  ["b2", "b3", "b4", "b5", "b5", "b4", "b3", "b2"],
  ["b2", "b2", "b2", "b2", "b2", "b2", "b2", "b2"],
  [null, null, null, null, null, null, null, null],
  [null, null, null, null, null, null, null, null],
  [null, null, null, null, null, null, null, null],
  [null, null, null, null, null, null, null, null],
  ["w2", "w2", "w2", "w2", "w2", "w2", "w2", "w2"],
  ["w2", "w3", "w4", "w5", "w5", "w4", "w3", "w2"]
];
